

#ignora as outras parte eu tava tentando fazer um site e colocar ele pra rodar la mas aq msm ele funciona de boa

import openai

# Configure a chave API (recomendado usar variáveis de ambiente para segurança)
openai.api_key = "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"

def enviar_mensagem(mensagem, lista_mensagens):
    try:
        # Adicione a mensagem do usuário à lista de mensagens
        lista_mensagens.append({"role": "user", "content": mensagem})

        # Enviar a solicitação para o OpenAI API
        resposta = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=lista_mensagens
        )

        # Obtenha a resposta do chatbot
        resposta_bot = resposta["choices"][0]["message"]["content"]

        # Adicione a resposta do chatbot à lista de mensagens
        lista_mensagens.append({"role": "assistant", "content": resposta_bot})

        return resposta_bot
    except Exception as e:
        return f"Erro: {e}"

# Lista de mensagens para manter o contexto
lista_mensagens = []

# Loop de interação com o chatbot
while True:
    texto = input("Pergunte o que quiser (ou digite 'sair' para encerrar): ")
    if texto.lower() == "sair":
        print("Encerrando o chatbot. Até mais!")
        break
    else:
        resposta = enviar_mensagem(texto, lista_mensagens)
        print("Chatbot:", resposta)
